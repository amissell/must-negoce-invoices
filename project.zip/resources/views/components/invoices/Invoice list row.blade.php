
<tr>
    <td class="px-6 py-4">
        <div class="flex items-center">
            <span class="font-mono font-semibold">{{ $invoice->invoice_number }}</span>
            
            <!-- Type Badge -->
            @if($invoice->isManual())
                <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/>
                    </svg>
                    Manuelle
                </span>
            @else
                <span class="ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                    </svg>
                    Automatique
                </span>
            @endif
        </div>
    </td>
    
    <td class="px-6 py-4">
        {{ $invoice->client_name }}
        
        <!-- Show additional client info for manual invoices -->
        @if($invoice->isManual() && ($invoice->client_phone || $invoice->client_email))
            <div class="text-sm text-gray-500 mt-1">
                @if($invoice->client_phone)
                    <div class="flex items-center">
                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/>
                        </svg>
                        {{ $invoice->client_phone }}
                    </div>
                @endif
                @if($invoice->client_email)
                    <div class="flex items-center mt-0.5">
                        <svg class="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
                        </svg>
                        {{ $invoice->client_email }}
                    </div>
                @endif
            </div>
        @endif
    </td>
    
    <td class="px-6 py-4">
        {{ $invoice->formatted_date }}
    </td>
    
    <td class="px-6 py-4 text-right font-mono font-semibold">
        {{ $invoice->formatted_total }}
    </td>
    
    <td class="px-6 py-4">
        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
            @if($invoice->payment_mode === 'CH') bg-yellow-100 text-yellow-800
            @elseif($invoice->payment_mode === 'ESP') bg-green-100 text-green-800
            @elseif($invoice->payment_mode === 'VIR') bg-blue-100 text-blue-800
            @else bg-purple-100 text-purple-800
            @endif">
            {{ $invoice->payment_mode }}
        </span>
    </td>
    
    <td class="px-6 py-4">
        <div class="flex items-center space-x-2">
            <!-- View Button -->
            <a href="{{ route('invoices.show', $invoice) }}" 
               class="text-blue-600 hover:text-blue-800 transition"
               title="Voir la facture">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                </svg>
            </a>
            
            <!-- Download PDF Button -->
            <a href="{{ route('invoices.download', $invoice) }}" 
               class="text-green-600 hover:text-green-800 transition"
               title="Télécharger PDF">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
            </a>
            
            <!-- Delete Button (if needed) -->
            <form action="{{ route('invoices.destroy', $invoice) }}" method="POST" class="inline"
                  onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette facture ?');">
                @csrf
                @method('DELETE')
                <button type="submit" class="text-red-600 hover:text-red-800 transition"
                        title="Supprimer">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                    </svg>
                </button>
            </form>
        </div>
    </td>
</tr>
<div class="mb-6">
    <div class="border-b border-gray-200">
        <nav class="-mb-px flex space-x-8">
            <a href="{{ route('invoices.index') }}" 
               class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm {{ !request('type') ? 'border-blue-500 text-blue-600' : '' }}">
                Toutes les factures
                <span class="ml-2 bg-gray-100 text-gray-900 py-0.5 px-2.5 rounded-full text-xs font-medium">
                    {{ $totalInvoices ?? 0 }}
                </span>
            </a>
            
            <a href="{{ route('invoices.index', ['type' => 'manual']) }}" 
               class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm {{ request('type') === 'manual' ? 'border-blue-500 text-blue-600' : '' }}">
                Factures Manuelles
                <span class="ml-2 bg-blue-100 text-blue-900 py-0.5 px-2.5 rounded-full text-xs font-medium">
                    {{ $manualCount ?? 0 }}
                </span>
            </a>
            
            <a href="{{ route('invoices.index', ['type' => 'automatic']) }}" 
               class="border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm {{ request('type') === 'automatic' ? 'border-blue-500 text-blue-600' : '' }}">
                Factures Automatiques
                <span class="ml-2 bg-green-100 text-green-900 py-0.5 px-2.5 rounded-full text-xs font-medium">
                    {{ $automaticCount ?? 0 }}
                </span>
            </a>
        </nav>
    </div>
</div>